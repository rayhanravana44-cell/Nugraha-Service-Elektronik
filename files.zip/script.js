document.getElementById('y').textContent=new Date().getFullYear();
var gal=document.getElementById('gal'),fl=document.getElementById('fl'),lb=document.getElementById('lb'),db=null,items=[];
function open_(cb){try{var r=indexedDB.open('nugraha',1);r.onupgradeneeded=function(){r.result.createObjectStore('p',{keyPath:'id',autoIncrement:true})};r.onsuccess=function(){db=r.result;cb()};r.onerror=function(){cb()}}catch(e){cb()}}
function load(){if(!db){render();return}try{var q=db.transaction('p').objectStore('p').getAll();q.onsuccess=function(){items=q.result||[];render()};q.onerror=render}catch(e){render()}}
function save(o,cb){if(!db){items.push(o);render();return}try{var t=db.transaction('p','readwrite');t.objectStore('p').add(o);t.oncomplete=function(){load()}}catch(e){items.push(o);render()}}
function del(id){if(!db){items=items.filter(function(i){return i.id!==id});render();return}try{var t=db.transaction('p','readwrite');t.objectStore('p').delete(id);t.oncomplete=load}catch(e){}}
function render(){gal.innerHTML='';
items.forEach(function(it){var d=document.createElement('div');d.className='ph';
var im=new Image();im.src=it.src;im.alt=it.cap||'Foto servis';d.appendChild(im);
if(it.cap){var c=document.createElement('div');c.className='cap';c.textContent=it.cap;d.appendChild(c)}
var x=document.createElement('button');x.className='x';x.textContent='×';x.title='Hapus';
x.onclick=function(e){e.stopPropagation();if(confirm('Hapus foto ini?'))del(it.id)};d.appendChild(x);
d.onclick=function(){lb.querySelector('img').src=it.src;lb.classList.add('on')};gal.appendChild(d)});
for(var i=items.length;i<Math.max(4,items.length+1)&&items.length<4;i++){var p=document.createElement('div');p.className='ph d';p.textContent='Foto belum ada. Klik "Tambah Foto".';gal.appendChild(p)}}
lb.onclick=function(){lb.classList.remove('on')};
document.getElementById('up').onclick=function(){fl.click()};
fl.onchange=function(){var cap=document.getElementById('cap').value.trim();
Array.prototype.forEach.call(fl.files,function(f){var r=new FileReader();r.onload=function(){var im=new Image();im.onload=function(){
var m=1100,s=Math.min(1,m/Math.max(im.width,im.height)),c=document.createElement('canvas');c.width=im.width*s;c.height=im.height*s;
c.getContext('2d').drawImage(im,0,0,c.width,c.height);save({src:c.toDataURL('image/jpeg',.8),cap:cap,id:Date.now()+Math.random()})};im.src=r.result};r.readAsDataURL(f)});
fl.value='';document.getElementById('cap').value=''};
(function(){var KEY='nugraha_reviews',REVIEWS=[{n:'Dikdik Hernardi',i:'Pelanggan servis',r:5,t:'Service cepat, lebih murah, ok.'}],mine=[],rate=0,E=function(i){return document.getElementById(i)};
try{mine=JSON.parse(localStorage.getItem(KEY)||'[]')}catch(e){mine=[]}
function sv(){try{localStorage.setItem(KEY,JSON.stringify(mine))}catch(e){}}
function st(n){return '\u2605\u2605\u2605\u2605\u2605'.slice(0,n)+'\u2606\u2606\u2606\u2606\u2606'.slice(0,5-n)}
function msg(t,ok){var m=E('rvMsg');m.textContent=t;m.style.color=ok?'#2e9e3a':'#d62b1f'}
function render(){var all=mine.concat(REVIEWS),s=0;all.forEach(function(r){s+=r.r});var avg=all.length?s/all.length:0;
E('rvAvg').textContent=all.length?avg.toFixed(1):'\u2013';E('rvStars').textContent=all.length?st(Math.round(avg)):'';E('rvCnt').textContent=all.length?all.length+' ulasan':'Belum ada ulasan';
var L=E('rvL');L.innerHTML='';
if(!all.length){var p=document.createElement('div');p.className='rvc';p.textContent='Belum ada ulasan. Jadilah yang pertama menulis ulasan!';L.appendChild(p);return}
all.forEach(function(r){var c=document.createElement('div');c.className='rvc';
var h=document.createElement('div');h.className='h';var n=document.createElement('strong');n.textContent=r.n;var a=document.createElement('span');a.className='stars';a.textContent=st(r.r);h.appendChild(n);h.appendChild(a);c.appendChild(h);
var t=document.createElement('p');t.textContent=r.t;c.appendChild(t);
var f=document.createElement('small');f.textContent=r.i+(r.d?' \u00b7 '+r.d:'');c.appendChild(f);
if(r.id){var x=document.createElement('button');x.className='dl2';x.type='button';x.textContent='Hapus';x.onclick=function(){if(confirm('Hapus ulasan ini?')){mine=mine.filter(function(m){return m.id!==r.id});sv();render()}};f.appendChild(x)}
L.appendChild(c)})}
function paint(){document.querySelectorAll('#rvIn button').forEach(function(b){b.classList.toggle('on',+b.dataset.v<=rate)})}
document.querySelectorAll('#rvIn button').forEach(function(b){b.onclick=function(){rate=+b.dataset.v;paint()}});
E('rvB').onclick=function(){var n=E('rvN').value.trim(),t=E('rvT').value.trim();
if(!rate)return msg('Pilih jumlah bintang dulu.');if(!n)return msg('Isi nama Anda.');if(t.length<5)return msg('Tulis ulasan minimal 5 karakter.');
mine.unshift({n:n,i:E('rvI').value,r:rate,t:t,d:new Date().toLocaleDateString('id-ID',{day:'numeric',month:'short',year:'numeric'}),id:Date.now()});sv();
E('rvN').value='';E('rvT').value='';rate=0;paint();render();msg('Terima kasih, ulasan Anda sudah ditambahkan.',true)};
render()})();
(function(){var $=function(i){return document.getElementById(i)};
function num(i){var v=parseFloat($(i).value);return isNaN(v)?null:v}
function eng(x,u){if(!isFinite(x))return '-';if(x===0)return '0 '+u;var p=['p','n','\u00b5','m','','k','M','G'],i=Math.max(-4,Math.min(3,Math.floor(Math.log10(Math.abs(x))/3)));return (+(x/Math.pow(10,i*3)).toPrecision(4))+' '+p[i+4]+u}
function e12(r){var d=Math.pow(10,Math.floor(Math.log10(r))),m=r/d,b=[1,1.2,1.5,1.8,2.2,2.7,3.3,3.9,4.7,5.6,6.8,8.2];for(var k=0;k<b.length;k++)if(b[k]>=m*.999)return b[k]*d;return 10*d}
var CN=['Hitam','Coklat','Merah','Oranye','Kuning','Hijau','Biru','Ungu','Abu-abu','Putih'],CH=['#111','#7b4a1e','#e02b20','#f08a1a','#f5d90a','#2e9e3a','#2a5bd7','#8a3fd0','#888','#f4f4f4'],TL=[[5,'Emas \u00b15%','#d4af37'],[10,'Perak \u00b110%','#c0c0c0'],[1,'Coklat \u00b11%','#7b4a1e'],[2,'Merah \u00b12%','#e02b20']];
function opt(s,l){l.forEach(function(o){var e=document.createElement('option');e.value=o[0];e.textContent=o[1];$(s).appendChild(e)})}
var dg=CN.map(function(n,i){return [i,n+' ('+i+')']});
opt('rb1',dg.slice(1));opt('rb2',dg);opt('rm',CN.map(function(n,i){return [i,n+' (\u00d710^'+i+')']}).concat([[-1,'Emas (\u00d70,1)'],[-2,'Perak (\u00d70,01)']]));opt('rt',TL.map(function(t,i){return [i,t[1]]}));
$('rb1').value='4';$('rb2').value='7';$('rm').value='2';
function calc(){
var v=num('oV'),i=num('oI'),r=num('oR'),o=$('oOut');if(i!==null)i/=1000;
if([v,i,r].filter(function(x){return x!==null}).length<2)o.textContent='Isi minimal dua kolom (V, I, atau R).';
else{if(v!==null&&i!==null)r=v/i;else if(v!==null)i=v/r;else v=i*r;o.innerHTML=isFinite(r)&&isFinite(i)&&isFinite(v)?'Tegangan: <b>'+eng(v,'V')+'</b><br>Arus: <b>'+eng(i,'A')+'</b><br>Hambatan: <b>'+eng(r,'\u03a9')+'</b><br>Daya: <b>'+eng(v*i,'W')+'</b>':'Nilai tidak valid (pembagian dengan nol).'}
var b1=+$('rb1').value,b2=+$('rb2').value,m=+$('rm').value,t=TL[+$('rt').value],ch=function(x){return x>=0?CH[x]:(x==-1?'#d4af37':'#c0c0c0')};
$('c1').style.background=CH[b1];$('c2').style.background=CH[b2];$('c3').style.background=ch(m);$('c4').style.background=t[2];
$('rOut').innerHTML='Nilai: <b>'+eng((b1*10+b2)*Math.pow(10,m),'\u03a9')+'</b> \u00b1'+t[0]+'%';
var s=num('lS'),f=num('lF'),c=num('lI'),lo=$('lOut');
if(s===null||f===null||!c)lo.textContent='Isi semua kolom.';else if(s<=f)lo.textContent='Tegangan sumber harus lebih besar dari Vf LED.';
else{var R=(s-f)/(c/1000),P=(s-f)*c/1000;lo.innerHTML='Resistor hitung: <b>'+eng(R,'\u03a9')+'</b><br>Nilai standar E12 terdekat (ke atas): <b>'+eng(e12(R),'\u03a9')+'</b><br>Daya resistor: <b>'+eng(P,'W')+'</b> (pakai rating minimal 2\u00d7 nilai ini)'}
var vi=num('dV'),a=num('dR1'),b=num('dR2'),d=$('dOut');
if(vi===null||a===null||b===null||a+b<=0)d.textContent='Isi semua kolom.';else d.innerHTML='Vout: <b>'+eng(vi*b/(a+b),'V')+'</b><br>Arus pembagi: <b>'+eng(vi/(a+b),'A')+'</b>';
var cr=num('cR'),cc=num('cC'),co=$('cOut');
if(!cr||!cc)co.textContent='Isi semua kolom (nilai lebih dari 0).';else{var tau=cr*cc*1e-6;co.innerHTML='Konstanta waktu (\u03c4): <b>'+eng(tau,'s')+'</b><br>Frekuensi cutoff: <b>'+eng(1/(2*Math.PI*tau),'Hz')+'</b><br>Kapasitor terisi ~99% setelah: <b>'+eng(5*tau,'s')+'</b>'}}
document.querySelectorAll('.tool input,.tool select').forEach(function(e){e.oninput=calc;e.onchange=calc});
document.querySelectorAll('.tabs button').forEach(function(bt){bt.onclick=function(){document.querySelectorAll('.tabs button').forEach(function(x){x.classList.remove('on')});document.querySelectorAll('.tool').forEach(function(x){x.classList.remove('on')});bt.classList.add('on');$(bt.dataset.t).classList.add('on')}});
calc()})();
function cyl(p,r,h,y,c){var n=16,g=document.createElement('div');g.className='cy';g.style.transform='translateY('+y+'px)';var w=2*r*Math.sin(Math.PI/n)+1.5,ap=r*Math.cos(Math.PI/n);
for(var k=0;k<n;k++){var a=k*360/n,f=document.createElement('i');f.style.cssText='width:'+w+'px;height:'+h+'px;left:'+(-w/2)+'px;top:'+(-h/2)+'px;background:'+c+';transform:rotateY('+a+'deg) translateZ('+ap+'px);filter:brightness('+(.7+.3*Math.cos(a*Math.PI/180))+')';g.appendChild(f)}
var d=document.createElement('i');d.style.cssText='width:'+2*r+'px;height:'+2*r+'px;left:'+(-r)+'px;top:'+(-r)+'px;border-radius:50%;background:'+c+';transform:translateY('+(-h/2)+'px) rotateX(90deg);filter:brightness(1.12)';g.appendChild(d);p.appendChild(g);return g}
(function(){var rc=document.getElementById('rc');cyl(rc,64,14,44,'#2b3440');var b=cyl(rc,62,70,1,'#f2efe6');
[['#e04b2b',-9],['#2fbf4a',9]].forEach(function(s){var e=document.createElement('i');e.style.cssText='width:14px;height:10px;left:'+(s[1]-7)+'px;top:6px;border-radius:2px;background:'+s[0]+';transform:translateZ(63px);box-shadow:0 1px 3px rgba(0,0,0,.4)';b.appendChild(e)});
cyl(rc,58,26,-47,'#d4dce6');cyl(rc,9,10,-65,'#f5a300')})();
(function(){var sel='.card,.steps div,.ph:not(.d)';
document.addEventListener('pointermove',function(e){if(e.pointerType==='touch')return;var t=e.target.closest&&e.target.closest(sel);if(!t)return;var r=t.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;t.style.setProperty('--ry',(x*16)+'deg');t.style.setProperty('--rx',(-y*16)+'deg')});
document.addEventListener('pointerout',function(e){var t=e.target.closest&&e.target.closest(sel);if(t){t.style.setProperty('--rx','0deg');t.style.setProperty('--ry','0deg')}})})();
open_(load);
